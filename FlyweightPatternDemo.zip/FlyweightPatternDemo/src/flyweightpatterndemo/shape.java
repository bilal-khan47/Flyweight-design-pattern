package FlyweightPattern_TutorialsPoint;

public interface Shape {
	   void draw();
	}
